#### luci版本 24.10.2 固件不是传统ext4和squashfs格式 而是btrfs格式 支持快照
#### 单网口机型后台地址 `没有没有没有,需查询` 请在上级路由器的dhcp列表中查询具体的局域网ip
#### 多网口机型后台地址：`192.168.100.1`
#### 用户名 `root` 密码：password
#### 是否带docker: 根据用户选择
#### 默认软件包大小 1GB
#### 内核版本:根据用户选择
#### rootfs.tar.gz 构建采用ImmortalWrt的ImageBuilder
#### 打包img 采用 `flippy-openwrt-actions`
#### 默认底包位置：https://github.com/wukongdaily/AutoBuildImmortalWrt/releases/tag/rootfs

## 各位尽量不要直接使用项目中的release 要自己fork项目后自行构建  <br> 本项目中的release仅用于作者测试 且会定期删除
##### 若release中下载吃力 可在国内加速站下载 
[![Github](https://img.shields.io/badge/Release文件可在国内加速站下载-FC7C0D?logo=github&logoColor=fff&labelColor=000&style=for-the-badge)](https://wkdaily.cpolar.top/archives/1) 
>  支持的机型列表：
- e20c - e24c - e25 - e52c - e54c - rock5b - rock5c
- r66s - r68s - ht2 - h28k - h66k - h68k- h69k - h69k-max - h88k - h88k-v3
- jp-tvbox - l1pro
- s905 - s905x2 - s905x3 - s912 - s922x - s922x-n2