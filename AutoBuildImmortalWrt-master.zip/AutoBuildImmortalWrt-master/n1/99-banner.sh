#!/bin/sh
cp /mnt/banner /etc/banner
rm /mnt/banner