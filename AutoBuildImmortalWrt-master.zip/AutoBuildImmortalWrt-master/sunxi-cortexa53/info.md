[![Github](https://img.shields.io/badge/Release文件可在国内加速站下载-FC7C0D?logo=github&logoColor=fff&labelColor=000&style=for-the-badge)](https://wkdaily.cpolar.top/archives/1) 
#### 1、若是单网口设备默认DHCP模式 比如Zero3
#### 2、若是双网口设备 比如R1S 
#### Lan口 地址 `192.168.100.1` Wan：DHCP
#### 用户名 `root` 密码：无
